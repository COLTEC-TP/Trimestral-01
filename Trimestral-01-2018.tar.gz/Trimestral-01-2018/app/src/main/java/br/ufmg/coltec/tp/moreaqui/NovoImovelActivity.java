package br.ufmg.coltec.tp.moreaqui;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class NovoImovelActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_novo_imovel);

        Button addButton = findViewById(R.id.addImovel);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText nome = (EditText)findViewById(R.id.nome);
                EditText cidade = (EditText)findViewById(R.id.cidade);
                EditText endereco = (EditText)findViewById(R.id.endereco);
                EditText telefone = (EditText)findViewById(R.id.telefone);
                EditText valor = (EditText)findViewById(R.id.valor);


                String Snome = nome.getText().toString();
                String Scidade = cidade.getText().toString();
                String Sendereco = endereco.getText().toString();
                String Stelefone = telefone.getText().toString();
                Double Dvalor =  Double.parseDouble(valor.getText().toString());

                Imovel novoImovel;
                ImovelDAO DAO;

                DAO = ImovelDAO.getInstance();
                novoImovel=new Imovel(Snome, Sendereco, Scidade, Dvalor, Stelefone);

                //DAO.adicionarImovel(novoImovel);
            }
        });



    }
}
